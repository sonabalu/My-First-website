
export enum Category {
  HOUSING = 'Housing',
  FOOD = 'Food & Groceries',
  TRANSPORT = 'Transport',
  ENTERTAINMENT = 'Entertainment',
  UTILITIES = 'Utilities',
  HEALTH = 'Health',
  OTHER = 'Other'
}

export enum UserRole {
  HOUSEHOLD_HEAD = 'Household Head',
  PARTNER = 'Partner',
  MEMBER = 'Family Member',
  VIEWER = 'Viewer (Child/Guest)'
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  avatar: string;
  familyId: string;
}

export interface Family {
  id: string;
  name: string;
  memberIds: string[];
}

export interface Transaction {
  id: string;
  amount: number;
  category: Category;
  description: string;
  date: string;
  userId: string; 
  userName: string;
  familyId: string;
}

export interface Bill {
  id: string;
  title: string;
  amount: number;
  dueDate: string;
  category: Category;
  isPaid: boolean;
  familyId: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline?: string;
  category: 'vacation' | 'emergency' | 'large-purchase' | 'other';
  familyId: string;
}

export interface WishlistItem {
  id: string;
  title: string;
  price: number;
  suggestedBy: string;
  votes: number;
  imageUrl?: string;
  category: Category;
  familyId: string;
}

export interface SavingsChallenge {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  daysLeft: number;
  participants: string[];
  familyId: string;
}
