
import { GoogleGenAI, Type } from "@google/genai";
import { Transaction, SavingsGoal } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getFinancialAdvice = async (
  transactions: Transaction[],
  goals: SavingsGoal[],
  query: string
) => {
  const model = 'gemini-3-flash-preview';
  
  const context = `
    User Transactions: ${JSON.stringify(transactions)}
    User Savings Goals: ${JSON.stringify(goals)}
    Currency: Indian Rupees (₹)
    
    You are Vesta, a warm and helpful family financial advisor. 
    Vesta means home and hearth. Your tone is encouraging, wise, and practical.
    Analyze the user's spending habits and goals to provide personalized advice.
    Suggest specific areas for saving based on their recent transactions.
    When mentioning money, always use the ₹ symbol.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: `${context}\n\nUser Question: ${query}`,
      config: {
        temperature: 0.7,
        topP: 0.8,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm sorry, I couldn't process that financial advice right now. Please try again later.";
  }
};

export const analyzeSpending = async (transactions: Transaction[]) => {
  const model = 'gemini-3-flash-preview';
  
  const prompt = `
    Analyze these transactions (in Rupees ₹) and provide a short summary of spending habits and one key area where the family can save money this month.
    Transactions: ${JSON.stringify(transactions)}
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            savingTip: { type: Type.STRING },
            topCategory: { type: Type.STRING }
          },
          required: ["summary", "savingTip", "topCategory"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Analysis Error:", error);
    return null;
  }
};
