
import React, { useState } from 'react';
import { SavingsGoal } from '../types';

interface GoalsProps {
  goals: SavingsGoal[];
  // Fix: Exclude familyId from the onAdd parameter since it's added in the parent context
  onAdd: (g: Omit<SavingsGoal, 'id' | 'familyId'>) => void;
  onUpdate: (id: string, amount: number) => void;
}

const CATEGORY_IMAGES: Record<string, string> = {
  vacation: 'https://images.unsplash.com/photo-1506484334402-40ff22e05a6d?auto=format&fit=crop&q=80&w=800',
  emergency: 'https://images.unsplash.com/photo-1542810634-71277d95dcbb?auto=format&fit=crop&q=80&w=800',
  'large-purchase': 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=800',
  other: 'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&q=80&w=800'
};

const Goals: React.FC<GoalsProps> = ({ goals, onAdd, onUpdate }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [showContribution, setShowContribution] = useState<string | null>(null);
  const [contAmount, setContAmount] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    targetAmount: '',
    currentAmount: '0',
    category: 'vacation' as any
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Fix: Call onAdd with fields provided by the form, now matching the updated prop type
    onAdd({
      name: formData.name,
      targetAmount: parseFloat(formData.targetAmount),
      currentAmount: parseFloat(formData.currentAmount),
      category: formData.category
    });
    setFormData({ name: '', targetAmount: '', currentAmount: '0', category: 'vacation' });
    setIsAdding(false);
  };

  const handleContribute = (id: string) => {
    const amount = parseFloat(contAmount);
    if (!isNaN(amount)) {
      onUpdate(id, amount);
      setContAmount('');
      setShowContribution(null);
    }
  };

  return (
    <div className="space-y-12 slide-up-fade">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-6xl serif font-bold text-[#432818]">Family Aspirations</h2>
          <p className="text-gray-500 font-medium mt-2 text-lg">Dreaming together, saving together.</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-[#432818] text-white px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl font-black text-xs uppercase tracking-widest active:scale-95"
        >
          {isAdding ? 'Close' : '+ Plant New Vision'}
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSubmit} className="bg-white p-12 rounded-[4rem] shadow-2xl border border-orange-50 grid grid-cols-1 md:grid-cols-2 gap-10 animate-float">
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-[#cb997e] uppercase tracking-[0.3em] mb-3">The Shared Dream</label>
            <input 
              required
              type="text" 
              placeholder="e.g. Winter Cabin in Manali"
              className="w-full bg-[#fffaf2] border-none rounded-[1.5rem] px-8 py-5 focus:ring-4 focus:ring-orange-100 outline-none transition-all text-[#432818] font-bold text-xl"
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-[#cb997e] uppercase tracking-[0.3em] mb-3">Target (₹)</label>
            <input 
              required
              type="number" 
              placeholder="0"
              className="w-full bg-[#fffaf2] border-none rounded-[1.5rem] px-8 py-5 focus:ring-4 focus:ring-orange-100 outline-none transition-all text-[#432818] font-bold text-xl"
              value={formData.targetAmount}
              onChange={e => setFormData({ ...formData, targetAmount: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-[#cb997e] uppercase tracking-[0.3em] mb-3">Vibe</label>
            <select 
              className="w-full bg-[#fffaf2] border-none rounded-[1.5rem] px-8 py-5 focus:ring-4 focus:ring-orange-100 outline-none transition-all text-[#432818] font-bold text-xl appearance-none"
              value={formData.category}
              onChange={e => setFormData({ ...formData, category: e.target.value as any })}
            >
              <option value="vacation">Family Journey</option>
              <option value="emergency">Safety Nest</option>
              <option value="large-purchase">Major Milestone</option>
              <option value="other">Hearth Improvement</option>
            </select>
          </div>
          <button type="submit" className="md:col-span-2 bg-[#cb997e] text-white py-6 rounded-[2.5rem] font-black text-xl hover:scale-[1.02] transition-all shadow-2xl active:scale-[0.98]">
            Set Vision
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {goals.map((goal, idx) => {
          const progress = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
          return (
            <div key={goal.id} className={`bg-white rounded-[4rem] border border-white p-2 shadow-sm soft-hover slide-up-fade stagger-${(idx % 4) + 1}`}>
              <div className="h-64 relative overflow-hidden rounded-[3.5rem] m-2">
                <img 
                  src={CATEGORY_IMAGES[goal.category] || CATEGORY_IMAGES.other} 
                  className="w-full h-full object-cover"
                  alt={goal.name}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#432818]/90 via-[#432818]/20 to-transparent flex flex-col justify-end p-10">
                   <span className="text-orange-200 text-[10px] font-black uppercase tracking-[0.4em] mb-3">{goal.category}</span>
                   <h3 className="text-4xl font-bold text-white serif">{goal.name}</h3>
                </div>
              </div>

              <div className="p-10 space-y-10">
                <div className="flex justify-between items-end">
                   <div>
                      <p className="text-[10px] font-black text-[#cb997e] uppercase tracking-widest mb-2">Collected</p>
                      <p className="text-4xl font-black text-[#432818]">₹{goal.currentAmount.toLocaleString('en-IN')}</p>
                   </div>
                   <div className="text-right">
                      <p className="text-[10px] font-black text-[#cb997e] uppercase tracking-widest mb-2">Target</p>
                      <p className="text-xl font-bold text-gray-400">₹{goal.targetAmount.toLocaleString('en-IN')}</p>
                   </div>
                </div>

                <div className="relative h-4 bg-[#fffaf2] rounded-full overflow-hidden shadow-inner">
                  <div 
                    className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#cb997e] to-[#432818] rounded-full transition-all duration-[1500ms] ease-out"
                    style={{ width: `${progress}%` }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-[8px] font-black text-[#432818] mix-blend-difference">{Math.round(progress)}% Complete</span>
                  </div>
                </div>

                {showContribution === goal.id ? (
                  <div className="flex gap-3 animate-float bg-[#fffaf2] p-4 rounded-[2rem] border border-orange-50">
                    <input 
                      autoFocus
                      type="number" 
                      placeholder="Amount to add"
                      className="flex-1 bg-white border-none rounded-2xl px-6 py-4 text-sm font-bold text-[#432818] outline-none focus:ring-4 focus:ring-orange-100"
                      value={contAmount}
                      onChange={e => setContAmount(e.target.value)}
                    />
                    <button 
                      onClick={() => handleContribute(goal.id)}
                      className="bg-[#432818] text-white px-8 py-4 rounded-2xl text-xs font-black shadow-xl"
                    >
                      Log
                    </button>
                    <button onClick={() => setShowContribution(null)} className="p-4 text-gray-400 hover:text-[#432818] transition-colors">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => setShowContribution(goal.id)}
                    className="w-full py-6 bg-[#fffaf2] text-[#432818] border border-orange-100 rounded-[2.5rem] font-black text-xs uppercase tracking-widest hover:bg-[#ffe8d6] transition-all flex items-center justify-center gap-3"
                  >
                    Add Contribution
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Goals;
