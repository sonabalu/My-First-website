
import React, { useState } from 'react';
import { SavingsChallenge } from '../types';

interface ChallengesProps {
  challenges: SavingsChallenge[];
  onUpdate: (id: string, amount: number) => void;
}

const Challenges: React.FC<ChallengesProps> = ({ challenges, onUpdate }) => {
  const [activeInput, setActiveInput] = useState<string | null>(null);
  const [amt, setAmt] = useState('');

  const handleApply = (id: string) => {
    const value = parseFloat(amt);
    if (!isNaN(value)) {
      onUpdate(id, value);
      setAmt('');
      setActiveInput(null);
    }
  };

  return (
    <div className="space-y-16 animate-bloom">
      <header>
        <h2 className="text-7xl serif font-bold text-[#1e1b29] title-shimmer">Saving Sprints</h2>
        <p className="text-gray-400 font-medium mt-4 text-xl">Coordinated efforts to build the home's future faster.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {challenges.map((challenge, idx) => {
          const progress = (challenge.current / challenge.target) * 100;
          return (
            <div key={challenge.id} className="glass-premium p-12 rounded-[4.5rem] soft-hover border-none relative overflow-hidden group">
               <div className="absolute top-0 right-0 p-8">
                  <span className="text-orange-400 text-[10px] font-black uppercase tracking-[0.4em]">{challenge.daysLeft} Days Left</span>
               </div>
               
               <div className="space-y-8">
                  <div className="space-y-2">
                    <h3 className="text-4xl font-black text-[#1e1b29] tracking-tight">{challenge.title}</h3>
                    <p className="text-gray-400 font-medium leading-relaxed">{challenge.description}</p>
                  </div>

                  <div className="space-y-4">
                     <div className="flex justify-between items-end">
                        <p className="text-[10px] font-black uppercase tracking-widest text-[#b497ff]">Current Speed</p>
                        <p className="text-2xl font-black text-[#1e1b29]">₹{challenge.current.toLocaleString()} <span className="text-xs text-gray-300 font-medium">/ ₹{challenge.target.toLocaleString()}</span></p>
                     </div>
                     <div className="h-4 bg-white/60 rounded-full overflow-hidden shadow-inner p-1">
                        <div className="h-full bg-gradient-to-r from-[#b497ff] to-[#ff9d8c] rounded-full transition-all duration-[2000ms]" style={{ width: `${progress}%` }}></div>
                     </div>
                  </div>

                  {activeInput === challenge.id ? (
                    <div className="flex gap-4 animate-bloom">
                       <input 
                        autoFocus
                        type="number" 
                        placeholder="Amt..." 
                        className="flex-1 bg-white border-none rounded-2xl px-6 py-4 font-bold outline-none shadow-inner text-sm"
                        value={amt}
                        onChange={e => setAmt(e.target.value)}
                       />
                       <button onClick={() => handleApply(challenge.id)} className="bg-[#1a1625] text-white px-8 py-4 rounded-2xl font-black text-xs">Apply</button>
                       <button onClick={() => setActiveInput(null)} className="px-6 py-4 text-gray-300 font-black text-xs">Cancel</button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setActiveInput(challenge.id)}
                      className="w-full py-5 bg-[#1a1625]/5 text-[#1a1625] rounded-[2rem] font-black text-[10px] uppercase tracking-widest hover:bg-[#1a1625] hover:text-white transition-all active:scale-95"
                    >
                      Record Progress
                    </button>
                  )}

                  <div className="flex items-center gap-4 pt-4 border-t border-gray-100">
                     <p className="text-[9px] font-black uppercase tracking-widest text-gray-400">Unit Members:</p>
                     <div className="flex -space-x-4">
                        {challenge.participants.map(name => (
                           <img key={name} src={`https://i.pravatar.cc/150?u=${name}`} className="w-10 h-10 rounded-full border-4 border-white shadow-sm hover:translate-y-[-5px] transition-transform" alt={name} />
                        ))}
                     </div>
                  </div>
               </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Challenges;
