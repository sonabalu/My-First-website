
import React, { useMemo, useState, useEffect } from 'react';
import { Transaction, SavingsGoal, Bill, User } from '../types';

interface DashboardProps {
  transactions: Transaction[];
  goals: SavingsGoal[];
  bills: Bill[];
  currentUser: User;
}

const Dashboard: React.FC<DashboardProps> = ({ transactions, goals, bills, currentUser }) => {
  const [animatedTotal, setAnimatedTotal] = useState(0);

  const totalSpent = useMemo(() => transactions.reduce((acc, t) => acc + t.amount, 0), [transactions]);
  const unpaidBills = useMemo(() => bills.filter(b => !b.isPaid), [bills]);
  const totalDue = useMemo(() => unpaidBills.reduce((acc, b) => acc + b.amount, 0), [unpaidBills]);
  
  const monthlyBudget = 150000; 
  const safeToSpend = Math.max(0, monthlyBudget - totalSpent - totalDue);
  const safePercent = (safeToSpend / monthlyBudget) * 100;

  const strokeDash = 2 * Math.PI * 140; 
  const dashOffset = strokeDash - (safePercent / 100) * strokeDash;

  useEffect(() => {
    const timer = setTimeout(() => setAnimatedTotal(safeToSpend), 500);
    return () => clearTimeout(timer);
  }, [safeToSpend]);

  return (
    <div className="space-y-32">
      {/* High-Impact Visual Summary */}
      <section className="flex flex-col items-center justify-center py-10 relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#b497ff]/5 rounded-full blur-[200px] pointer-events-none"></div>
        
        <div className="relative group transition-all duration-1000 animate-hearth">
          <svg className="w-[480px] h-[480px] transform -rotate-90">
            <circle cx="240" cy="240" r="140" stroke="rgba(26, 22, 37, 0.03)" strokeWidth="16" fill="transparent" strokeLinecap="round" />
            <circle
              cx="240"
              cy="240"
              r="140"
              stroke="#b497ff"
              strokeWidth="18"
              fill="transparent"
              strokeDasharray={strokeDash}
              strokeDashoffset={dashOffset}
              strokeLinecap="round"
              className="transition-all duration-[3000ms] ease-out filter drop-shadow-[0_0_15px_rgba(180,151,255,0.5)]"
            />
          </svg>

          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-12">
            <div className="mb-10 flex flex-col items-center group-hover:scale-110 transition-transform duration-700">
               <div className="w-2 h-16 bg-gradient-to-t from-[#b497ff] to-transparent rounded-full animate-pulse blur-[1.5px]"></div>
               <div className="w-5 h-5 bg-[#b497ff] rounded-full blur-[3px] mt-[-8px]"></div>
            </div>
            <p className="text-[10px] font-black uppercase tracking-[1em] text-gray-400 mb-4 transition-colors group-hover:text-[#b497ff]">Hearth Presence</p>
            <h3 className="text-9xl font-black text-[#1a1625] tracking-tighter leading-none mb-4">
              ₹{animatedTotal.toLocaleString('en-IN')}
            </h3>
            <div className="px-6 py-2 bg-emerald-50 rounded-full">
               <p className="text-[9px] font-black uppercase tracking-[0.4em] text-emerald-500">Resonant Flow Healthy</p>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Snapshot */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {[
          { label: 'Settled This Cycle', value: `₹${totalSpent.toLocaleString()}`, color: 'text-[#1a1625]', icon: '🌑', desc: 'Monthly usage logged' },
          { label: 'Upcoming Dues', value: `₹${totalDue.toLocaleString()}`, color: 'text-orange-400', icon: '⏳', desc: 'Awaiting action' },
          { label: 'Hearth Visions', value: goals.length, color: 'text-[#b497ff]', icon: '✨', desc: 'Family aspirations' }
        ].map((stat, i) => (
          <div 
            key={i} 
            className="glass-premium p-12 rounded-[4rem] text-center relative overflow-hidden group"
            style={{ animationDelay: `${i * 0.1}s` }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent pointer-events-none"></div>
            <span className="text-5xl block mb-6 transform group-hover:scale-125 group-hover:rotate-12 transition-transform duration-500">{stat.icon}</span>
            <p className="text-[10px] font-black uppercase tracking-[0.6em] text-gray-400 mb-3">{stat.label}</p>
            <p className={`text-5xl font-black ${stat.color} tracking-tight leading-tight mb-2`}>{stat.value}</p>
            <p className="text-[9px] font-bold text-gray-300 uppercase tracking-widest">{stat.desc}</p>
          </div>
        ))}
      </div>

      {/* High-Contrast Branding */}
      <section className="relative h-[600px] rounded-[6rem] overflow-hidden group shadow-[0_50px_100px_-20px_rgba(26,22,37,0.15)] border border-white">
        <img src="https://images.unsplash.com/photo-1544333346-64627448820e?auto=format&fit=crop&q=80&w=2000" className="absolute inset-0 w-full h-full object-cover grayscale opacity-30 transition-transform duration-[10000ms] group-hover:scale-110" alt="Hearth" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a1625] via-[#1a1625]/80 to-transparent"></div>
        <div className="absolute inset-0 flex flex-col justify-end p-24">
          <h4 className="text-7xl font-black text-white serif tracking-tight mb-6">The Shared Eternal.</h4>
          <p className="text-gray-400 text-2xl mt-4 font-light max-w-xl leading-relaxed opacity-80 group-hover:opacity-100 transition-opacity">
            Vesta is more than a ledger; it is the pulse of your household. Every log strengthens the flame, every vision brings you closer to the peak.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
