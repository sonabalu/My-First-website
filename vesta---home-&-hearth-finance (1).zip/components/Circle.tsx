
import React, { useState, useEffect } from 'react';
import { User, Family, UserRole } from '../types';

interface CircleProps {
  currentUser: User;
  onUpdateUser: (user: User) => void;
}

const Circle: React.FC<CircleProps> = ({ currentUser, onUpdateUser }) => {
  const [family, setFamily] = useState<Family | null>(null);
  const [members, setMembers] = useState<User[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newMember, setNewMember] = useState({ name: '', email: '', role: UserRole.MEMBER });

  const loadFamilyData = () => {
    const families: Family[] = JSON.parse(localStorage.getItem('vesta_families') || '[]');
    const currentFamily = families.find(f => f.id === currentUser.familyId);
    if (currentFamily) {
      setFamily(currentFamily);
      const allUsers: User[] = JSON.parse(localStorage.getItem('vesta_users') || '[]');
      const familyMembers = allUsers.filter(u => u.familyId === currentUser.familyId);
      setMembers(familyMembers);
    }
  };

  useEffect(() => {
    loadFamilyData();
  }, [currentUser.familyId]);

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    const allUsers: User[] = JSON.parse(localStorage.getItem('vesta_users') || '[]');
    const userId = Math.random().toString(36).substring(2, 9);
    
    const newUser: User = {
      id: userId,
      name: newMember.name,
      email: newMember.email,
      password: 'vesta', // Default password
      role: newMember.role,
      familyId: currentUser.familyId,
      avatar: `https://i.pravatar.cc/150?u=${userId}`
    };

    localStorage.setItem('vesta_users', JSON.stringify([...allUsers, newUser]));
    
    // Update Family object
    const families: Family[] = JSON.parse(localStorage.getItem('vesta_families') || '[]');
    const updatedFamilies = families.map(f => 
      f.id === currentUser.familyId ? { ...f, memberIds: [...f.memberIds, userId] } : f
    );
    localStorage.setItem('vesta_families', JSON.stringify(updatedFamilies));

    loadFamilyData();
    setIsAdding(false);
    setNewMember({ name: '', email: '', role: UserRole.MEMBER });
  };

  return (
    <div className="space-y-20 animate-bloom">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
        <div>
          <h2 className="text-8xl serif font-bold text-[#1a1625] tracking-tighter title-shimmer">The Circle</h2>
          <p className="text-gray-400 font-medium mt-6 text-2xl">The hearts that keep the hearth burning. {family?.name || 'Your Family'}.</p>
        </div>
        {currentUser.role === UserRole.HOUSEHOLD_HEAD && !isAdding && (
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-[#1a1625] text-white px-12 py-6 rounded-[2.5rem] font-black text-xs uppercase tracking-[0.4em] shadow-2xl hover:scale-105 active:scale-95 transition-all"
          >
            + Invoke Member
          </button>
        )}
      </header>

      {isAdding && (
        <form onSubmit={handleAddMember} className="glass-premium p-16 rounded-[4rem] grid grid-cols-1 md:grid-cols-3 gap-10 animate-bloom border-2 border-white">
          <div className="md:col-span-1">
             <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 block px-4">Member Name</label>
             <input required type="text" className="w-full bg-white/50 border-none rounded-[1.5rem] px-8 py-5 font-bold outline-none shadow-inner" placeholder="Priya" value={newMember.name} onChange={e => setNewMember({...newMember, name: e.target.value})} />
          </div>
          <div className="md:col-span-1">
             <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 block px-4">Member Email</label>
             <input required type="email" className="w-full bg-white/50 border-none rounded-[1.5rem] px-8 py-5 font-bold outline-none shadow-inner" placeholder="priya@vesta.home" value={newMember.email} onChange={e => setNewMember({...newMember, email: e.target.value})} />
          </div>
          <div className="md:col-span-1">
             <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 block px-4">Hearth Role</label>
             <select className="w-full bg-white/50 border-none rounded-[1.5rem] px-8 py-5 font-bold outline-none shadow-inner appearance-none" value={newMember.role} onChange={e => setNewMember({...newMember, role: e.target.value as UserRole})}>
                <option value={UserRole.PARTNER}>Partner</option>
                <option value={UserRole.MEMBER}>Member</option>
                <option value={UserRole.VIEWER}>Viewer</option>
             </select>
          </div>
          <div className="md:col-span-3 flex gap-4">
             <button type="submit" className="flex-1 bg-[#1a1625] text-white py-6 rounded-[2rem] font-black text-lg">Add to Circle</button>
             <button type="button" onClick={() => setIsAdding(false)} className="px-10 py-6 bg-white/50 text-gray-400 rounded-[2rem] font-black uppercase tracking-widest">Cancel</button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
        {members.map(member => (
          <div key={member.id} className="glass-premium p-12 rounded-[5rem] text-center border-none shadow-sm hover:shadow-2xl transition-all group">
            <div className="relative inline-block mb-10">
               <img src={member.avatar} className="w-32 h-32 rounded-[3.5rem] object-cover border-4 border-white shadow-xl transition-transform group-hover:rotate-12" alt="" />
               <div className={`absolute -bottom-2 -right-2 w-10 h-10 ${member.id === currentUser.id ? 'bg-emerald-400' : 'bg-[#b497ff]'} border-4 border-white rounded-full flex items-center justify-center`}>
                  <span className="text-white text-xs">{member.id === currentUser.id ? '⭐' : '✨'}</span>
               </div>
            </div>
            <h3 className="text-3xl font-black text-[#1a1625] mb-2">{member.name}</h3>
            <p className="text-[11px] font-black uppercase tracking-[0.4em] text-gray-400 mb-8">{member.role}</p>
            <div className="px-6 py-3 bg-[#1a1625]/5 rounded-full inline-block">
               <p className="text-[10px] font-bold text-gray-400 lowercase">{member.email}</p>
            </div>
          </div>
        ))}

        {!isAdding && currentUser.role === UserRole.HOUSEHOLD_HEAD && (
          <button 
            onClick={() => setIsAdding(true)}
            className="glass-premium p-12 rounded-[5rem] border-2 border-dashed border-gray-100 flex flex-col items-center justify-center gap-6 group hover:border-[#b497ff] transition-all"
          >
             <div className="w-20 h-20 bg-gray-50 rounded-[2.5rem] flex items-center justify-center group-hover:bg-[#b497ff]/10 transition-colors">
                <svg className="w-10 h-10 text-gray-300 group-hover:text-[#b497ff]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" />
                </svg>
             </div>
             <div>
                <p className="text-[10px] font-black uppercase tracking-[0.5em] text-gray-400 group-hover:text-[#1a1625]">Add Circle Member</p>
                <p className="text-[9px] font-medium text-gray-300 mt-2">Expansion is the way of prosperity</p>
             </div>
          </button>
        )}
      </div>

      <section className="glass-premium p-16 rounded-[5rem] border-none shadow-2xl relative overflow-hidden group">
         <div className="relative z-10 space-y-8">
            <h3 className="text-4xl font-bold serif text-[#1a1625]">Circle Vitality</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
               <div className="p-8 bg-white/50 rounded-[3rem]">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Circle Origin</p>
                  <p className="text-2xl font-black text-[#1a1625]">June 2024</p>
               </div>
               <div className="p-8 bg-white/50 rounded-[3rem]">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Total Strength</p>
                  <p className="text-2xl font-black text-[#1a1625]">{members.length} Spirits</p>
               </div>
               <div className="p-8 bg-white/50 rounded-[3rem]">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Harmony Status</p>
                  <p className="text-2xl font-black text-emerald-500">Perfectly Resonant</p>
               </div>
            </div>
         </div>
         <div className="absolute top-0 right-0 w-80 h-80 bg-purple-100/20 blur-[100px] pointer-events-none group-hover:bg-purple-100/40 transition-colors"></div>
      </section>
    </div>
  );
};

export default Circle;
