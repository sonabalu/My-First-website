
import React, { useState, useEffect } from 'react';

interface LumiCompanionProps {
  mood?: 'happy' | 'thinking' | 'resting' | 'excited';
  onSparkleClick?: () => void;
}

const LumiCompanion: React.FC<LumiCompanionProps> = ({ mood = 'happy', onSparkleClick }) => {
  const [wisdom, setWisdom] = useState<string | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  const wisdomQuotes = [
    "The hearth is warmest when all logs are shared. ✨",
    "A steady flow ensures a lasting fire. 🏠",
    "Lumi noticed your recent offering. Most noble! ☕",
    "Prosperity blooms where vision is shared by all. 🌸",
    "May your prosperity be as deep as the orchids. 🔥"
  ];

  const triggerWisdom = () => {
    const randomWisdom = wisdomQuotes[Math.floor(Math.random() * wisdomQuotes.length)];
    setWisdom(randomWisdom);
    setTimeout(() => setWisdom(null), 5000);
    if (onSparkleClick) onSparkleClick();
  };

  return (
    <div className="fixed bottom-12 right-12 z-50 flex flex-col items-end pointer-events-none">
      {wisdom && (
        <div className="mb-10 mr-4 glass-premium p-8 rounded-[3rem] rounded-br-none shadow-2xl border-2 border-white animate-bloom pointer-events-auto max-w-[260px] text-center">
          <p className="text-base font-bold text-[#1a1625] italic leading-relaxed tracking-tight">{wisdom}</p>
        </div>
      )}
      
      <div 
        onClick={triggerWisdom}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className={`w-28 h-28 cursor-pointer pointer-events-auto flex items-center justify-center relative group transition-all duration-700 ${mood === 'excited' ? 'animate-bounce' : 'animate-lumi'}`}
      >
        <div className={`absolute inset-0 bg-[#b497ff]/25 rounded-full transition-all duration-700 ${isHovered ? 'blur-[15px] scale-150' : 'blur-[5px] opacity-40'}`}></div>
        <div className={`relative w-18 h-18 bg-[#1a1625] rounded-[2.2rem] shadow-[0_25px_50px_-10px_rgba(26,22,37,0.5)] flex flex-col items-center justify-center overflow-hidden transition-all duration-500 ${isHovered ? 'scale-110 rotate-6' : ''}`}>
           <div className={`flex gap-4 mt-1 transition-all duration-500 ${isHovered ? 'translate-y-[-3px]' : ''}`}>
              <div className={`w-2.5 h-2.5 bg-white rounded-full transition-all duration-500 ${mood === 'excited' ? 'h-4 scale-x-125' : ''}`}></div>
              <div className={`w-2.5 h-2.5 bg-white rounded-full transition-all duration-500 ${mood === 'excited' ? 'h-4 scale-x-125' : ''}`}></div>
           </div>
           <div className={`w-5 h-1.5 bg-[#b497ff] rounded-full mt-4 transition-all duration-500 ${mood === 'excited' ? 'h-5 w-5 rounded-full bg-rose-400' : isHovered ? 'w-8 h-3 scale-110' : ''}`}></div>
        </div>
        <div className={`absolute inset-[-15px] border-2 border-[#b497ff]/20 rounded-[3rem] animate-ping pointer-events-none ${mood === 'excited' ? 'border-[#ff8e7a]' : ''}`}></div>
      </div>
    </div>
  );
};

export default LumiCompanion;
