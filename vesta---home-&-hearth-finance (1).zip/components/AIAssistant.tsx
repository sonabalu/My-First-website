
import React, { useState, useEffect } from 'react';
import { Transaction, SavingsGoal } from '../types';
import { getFinancialAdvice, analyzeSpending } from '../services/geminiService';

interface AIAssistantProps {
  transactions: Transaction[];
  goals: SavingsGoal[];
}

const AIAssistant: React.FC<AIAssistantProps> = ({ transactions, goals }) => {
  const [query, setQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; content: string }[]>([
    { role: 'ai', content: "Namaste! I am the spirit of Vesta. I have observed your household's hearth and would be honored to guide your path to prosperity. What wisdom do you seek today?" }
  ]);
  const [quickAnalysis, setQuickAnalysis] = useState<{ summary: string; savingTip: string; topCategory: string } | null>(null);

  useEffect(() => {
    const fetchAnalysis = async () => {
      const result = await analyzeSpending(transactions);
      if (result) setQuickAnalysis(result);
    };
    fetchAnalysis();
  }, [transactions]);

  const handleSend = async () => {
    if (!query.trim()) return;
    
    const userMsg = query;
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setQuery('');
    setIsTyping(true);

    const aiResponse = await getFinancialAdvice(transactions, goals, userMsg);
    
    setIsTyping(false);
    setMessages(prev => [...prev, { role: 'ai', content: aiResponse || "Forgive me, my wisdom is clouded at this moment." }]);
  };

  return (
    <div className="space-y-10 animate-fade-in flex flex-col h-[calc(100vh-160px)]">
      <header className="flex items-center gap-6">
        <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-[#9a3412] rounded-[1.5rem] flex items-center justify-center text-white shadow-2xl transform rotate-3 hearth-glow">
          <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
          </svg>
        </div>
        <div>
          <h2 className="text-5xl serif font-bold text-[#431407]">Hearth Wisdom</h2>
          <p className="text-amber-600 font-bold text-[11px] uppercase tracking-[0.3em] mt-1">Consulting the Spirit of Vesta</p>
        </div>
      </header>

      <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 flex flex-col bg-[#fffaf0] rounded-[4rem] shadow-2xl border border-orange-100 overflow-hidden relative">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/natural-paper.png')] opacity-10 pointer-events-none"></div>
          
          <div className="flex-1 overflow-y-auto p-12 space-y-8 scroll-smooth relative z-10">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-8 py-6 rounded-[2.5rem] text-base leading-relaxed ${
                  m.role === 'user' 
                  ? 'bg-[#431407] text-white rounded-br-none shadow-2xl' 
                  : 'bg-white/80 text-[#431407] rounded-bl-none border border-amber-100 font-medium italic serif'
                }`}>
                  <p className="whitespace-pre-line">{m.content}</p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white/80 px-8 py-6 rounded-[2.5rem] rounded-bl-none border border-amber-100">
                  <div className="flex gap-2">
                    <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-bounce" />
                    <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <div className="p-8 bg-orange-50/50 border-t border-orange-100 flex gap-6 items-center relative z-10">
            <input 
              type="text" 
              placeholder="Seek guidance for your home's prosperity..."
              className="flex-1 bg-white border-2 border-orange-100 rounded-[2rem] px-8 py-5 text-base focus:ring-4 focus:ring-amber-100 outline-none transition-all font-bold text-[#431407] placeholder:text-gray-300"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
            />
            <button 
              onClick={handleSend}
              className="bg-[#9a3412] text-white p-5 rounded-[1.5rem] hover:scale-105 transition-all shadow-2xl active:scale-95 flex-shrink-0 hearth-glow"
            >
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7-7 7M5 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        <div className="space-y-8 h-full overflow-y-auto pr-2">
          <div className="bg-gradient-to-br from-[#9a3412] to-[#431407] text-white p-10 rounded-[4rem] shadow-2xl relative overflow-hidden group">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full blur-3xl group-hover:bg-white/10 transition-colors"></div>
            <h3 className="text-2xl font-bold mb-8 serif flex items-center gap-4">
              <span className="p-3 bg-white/10 rounded-2xl">
                <svg className="w-6 h-6 text-amber-300" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 3a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V5a2 2 0 00-2-2H5zm0 2h10v7h-2l-1 2H8l-1-2H5V5z" clipRule="evenodd"/></svg>
              </span>
              Ancient Analysis
            </h3>
            {quickAnalysis ? (
              <div className="space-y-8">
                <div>
                  <p className="text-amber-200/50 text-[10px] font-black uppercase tracking-[0.3em] mb-3">Observations</p>
                  <p className="text-base leading-relaxed font-medium">{quickAnalysis.summary}</p>
                </div>
                <div className="pt-8 border-t border-white/10">
                  <p className="text-amber-200/50 text-[10px] font-black uppercase tracking-[0.3em] mb-3">Sacred Wisdom</p>
                  <p className="text-lg leading-relaxed italic font-serif text-amber-100">"{quickAnalysis.savingTip}"</p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center py-16 opacity-30">
                <div className="w-10 h-10 border-4 border-white/20 border-t-amber-400 rounded-full animate-spin mb-6" />
                <p className="text-xs font-black uppercase tracking-[0.3em]">Reading the embers...</p>
              </div>
            )}
          </div>

          <div className="bg-white p-10 rounded-[4rem] shadow-2xl border border-orange-50">
            <h3 className="font-black text-[#431407] text-sm uppercase tracking-widest mb-8 border-b border-orange-50 pb-4">Thought Starters</h3>
            <div className="space-y-4">
              {[
                "How to lower utility costs?",
                "Budget for the Diwali season",
                "Saving for the children's education",
                "Financial health of our hearth"
              ].map(q => (
                <button 
                  key={q}
                  onClick={() => setQuery(q)}
                  className="w-full text-left p-5 text-sm font-bold text-gray-500 hover:text-[#9a3412] hover:bg-orange-50 rounded-[1.75rem] transition-all border-2 border-transparent hover:border-orange-100 group flex items-center justify-between"
                >
                  {q}
                  <svg className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all transform translate-x-[-10px] group-hover:translate-x-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;
