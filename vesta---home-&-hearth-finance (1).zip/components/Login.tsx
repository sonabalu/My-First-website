
import React, { useState } from 'react';
import { User, UserRole, Family } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const ROLE_OPTIONS = [
  { value: UserRole.HOUSEHOLD_HEAD, label: 'Guardian', description: 'Oversight & Wisdom' },
  { value: UserRole.PARTNER, label: 'Partner', description: 'Shared Contribution' },
  { value: UserRole.MEMBER, label: 'Member', description: 'Daily Ledger' }
];

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [familyName, setFamilyName] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.HOUSEHOLD_HEAD);
  const [error, setError] = useState('');

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    const storedUsers: User[] = JSON.parse(localStorage.getItem('vesta_users') || '[]');
    
    if (storedUsers.find(u => u.email === email)) {
      setError('This soul is already registered in Vesta.');
      return;
    }

    const familyId = Math.random().toString(36).substring(2, 9);
    const userId = Math.random().toString(36).substring(2, 9);
    
    const newUser: User = {
      id: userId,
      name,
      email,
      password,
      role,
      familyId,
      avatar: `https://i.pravatar.cc/150?u=${userId}`
    };

    const newFamily: Family = {
      id: familyId,
      name: familyName || `${name}'s Hearth`,
      memberIds: [userId]
    };

    const storedFamilies: Family[] = JSON.parse(localStorage.getItem('vesta_families') || '[]');
    localStorage.setItem('vesta_users', JSON.stringify([...storedUsers, newUser]));
    localStorage.setItem('vesta_families', JSON.stringify([...storedFamilies, newFamily]));
    
    onLogin(newUser);
  };

  const handleSignin = (e: React.FormEvent) => {
    e.preventDefault();
    const storedUsers: User[] = JSON.parse(localStorage.getItem('vesta_users') || '[]');
    const user = storedUsers.find(u => u.email === email && u.password === password);

    if (user) {
      onLogin(user);
    } else {
      setError('The vault sequence or identity is incorrect.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-8 relative overflow-hidden bg-[#fdfbff] animate-bloom">
      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 glass-premium rounded-[5rem] overflow-hidden shadow-2xl border border-white">
        <div className="hidden lg:block relative h-full">
          <img 
            src="https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&q=80&w=2000" 
            className="absolute inset-0 w-full h-full object-cover grayscale-[0.3]" 
            alt="Family"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a1625] via-[#1a1625]/40 to-transparent flex flex-col justify-end p-20">
            <h1 className="text-8xl font-black text-white serif mb-8 tracking-tighter">Vesta</h1>
            <p className="text-gray-200 text-2xl font-light leading-relaxed max-w-md">
              Shared prosperity, tracked with grace and transparency.
            </p>
          </div>
        </div>

        <div className="p-16 md:p-24 flex flex-col justify-center bg-white/40 backdrop-blur-3xl">
          <div className="mb-12 text-center">
            <h2 className="text-6xl font-bold text-[#1a1625] serif mb-4">Welcome Home</h2>
            <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.6em]">Establish your family circle</p>
          </div>

          <div className="flex p-2 bg-[#1a1625]/5 rounded-[2.5rem] mb-12">
            <button 
              onClick={() => { setActiveTab('signin'); setError(''); }}
              className={`flex-1 py-5 text-[10px] font-black uppercase tracking-[0.4em] rounded-[2rem] transition-all ${activeTab === 'signin' ? 'bg-[#1a1625] text-white shadow-xl' : 'text-gray-400'}`}
            >
              Sign In
            </button>
            <button 
              onClick={() => { setActiveTab('signup'); setError(''); }}
              className={`flex-1 py-5 text-[10px] font-black uppercase tracking-[0.4em] rounded-[2rem] transition-all ${activeTab === 'signup' ? 'bg-[#1a1625] text-white shadow-xl' : 'text-gray-400'}`}
            >
              Found Circle
            </button>
          </div>

          {error && <p className="mb-6 text-rose-500 text-center font-bold text-sm animate-pulse">{error}</p>}

          <form onSubmit={activeTab === 'signup' ? handleSignup : handleSignin} className="space-y-8">
            {activeTab === 'signup' && (
              <>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-6">Identity Name</label>
                  <input required type="text" placeholder="Arjun" className="w-full bg-white rounded-[2rem] px-10 py-6 focus:ring-4 focus:ring-purple-100 outline-none font-bold text-xl shadow-inner border-none" value={name} onChange={e => setName(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-6">Family Circle Name</label>
                  <input required type="text" placeholder="The Sharma Hearth" className="w-full bg-white rounded-[2rem] px-10 py-6 focus:ring-4 focus:ring-purple-100 outline-none font-bold text-xl shadow-inner border-none" value={familyName} onChange={e => setFamilyName(e.target.value)} />
                </div>
              </>
            )}

            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-6">Sanctuary Email</label>
              <input required type="email" placeholder="arjun@vesta.home" className="w-full bg-white rounded-[2rem] px-10 py-6 focus:ring-4 focus:ring-purple-100 outline-none font-bold text-xl shadow-inner border-none" value={email} onChange={e => setEmail(e.target.value)} />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-6">Vault Sequence</label>
              <input required type="password" placeholder="••••••••" className="w-full bg-white rounded-[2rem] px-10 py-6 focus:ring-4 focus:ring-purple-100 outline-none font-bold text-xl shadow-inner border-none" value={password} onChange={e => setPassword(e.target.value)} />
            </div>

            <button type="submit" className="w-full bg-[#1a1625] text-white py-8 rounded-[3rem] font-black text-2xl hover:bg-[#b497ff] transition-all shadow-2xl active:scale-95 mt-10">
              {activeTab === 'signup' ? 'Ignite the Hearth' : 'Enter the Circle'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
