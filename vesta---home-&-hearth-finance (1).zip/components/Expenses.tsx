
import React, { useState } from 'react';
import { Category, Transaction } from '../types';

interface ExpensesProps {
  transactions: Transaction[];
  // Fix: Exclude parent-managed fields (id, userId, userName, familyId) from the onAdd parameter
  onAdd: (t: Omit<Transaction, 'id' | 'userId' | 'userName' | 'familyId'>) => void;
}

const Expenses: React.FC<ExpensesProps> = ({ transactions, onAdd }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    category: Category.FOOD,
    description: '',
    date: new Date().toISOString().split('T')[0]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Fix: Successfully call onAdd with the fields collected in the form, now matching the updated prop type
    onAdd({
      amount: parseFloat(formData.amount),
      category: formData.category,
      description: formData.description,
      date: formData.date
    });
    
    // Coin particle animation trigger
    const animationLayer = document.getElementById('animation-layer');
    if (animationLayer) {
      for (let i = 0; i < 8; i++) {
        const coin = document.createElement('div');
        coin.className = 'coin-particle';
        coin.innerText = '🪙';
        coin.style.left = `${window.innerWidth / 2 + (Math.random() - 0.5) * 200}px`;
        coin.style.top = `${window.innerHeight / 2}px`;
        coin.style.fontSize = '24px';
        animationLayer.appendChild(coin);
        setTimeout(() => coin.remove(), 1000);
      }
    }

    setFormData({ amount: '', category: Category.FOOD, description: '', date: new Date().toISOString().split('T')[0] });
    setIsAdding(false);
  };

  return (
    <div className="space-y-20 animate-bloom">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-12">
        <div>
          <h2 className="text-8xl serif font-bold text-[#1a1625] tracking-tighter title-shimmer">Family Logs</h2>
          <p className="text-gray-400 font-medium mt-6 text-2xl leading-relaxed max-w-lg">Every log is an ember for the hearth. Transparency builds prosperity.</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-[#1a1625] text-white px-14 py-7 rounded-[2.5rem] hover:scale-105 transition-all shadow-2xl font-black text-xs uppercase tracking-[0.5em] active:scale-95 magnetic"
        >
          {isAdding ? 'Archive Ledger' : '+ Create Entry'}
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSubmit} className="glass-premium p-16 rounded-[5rem] border-2 border-white grid grid-cols-1 md:grid-cols-2 gap-12 animate-bloom relative overflow-hidden">
          <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-orange-100/30 blur-[120px] pointer-events-none"></div>
          <div className="md:col-span-2">
            <label className="block text-[11px] font-black text-[#1a1625] uppercase tracking-[0.6em] mb-6">Narrative of Entry</label>
            <input 
              required
              type="text" 
              placeholder="e.g. Lavender Garden Maintenance Cycle"
              className="w-full bg-white/60 border-none rounded-[2.5rem] px-12 py-8 focus:ring-8 focus:ring-purple-50 outline-none transition-all text-[#1a1625] font-bold text-3xl shadow-inner"
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-[11px] font-black text-[#1a1625] uppercase tracking-[0.6em] mb-6">Offering (₹)</label>
            <input 
              required
              type="number" 
              step="0.01"
              placeholder="0.00"
              className="w-full bg-white/60 border-none rounded-[2.5rem] px-12 py-8 focus:ring-8 focus:ring-purple-50 outline-none transition-all text-[#1a1625] font-black text-4xl shadow-inner"
              value={formData.amount}
              onChange={e => setFormData({ ...formData, amount: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-[11px] font-black text-[#1a1625] uppercase tracking-[0.6em] mb-6">Sphere</label>
            <select 
              className="w-full bg-white/60 border-none rounded-[2.5rem] px-12 py-8 focus:ring-8 focus:ring-purple-50 outline-none transition-all text-[#1a1625] font-bold text-2xl appearance-none shadow-inner"
              value={formData.category}
              onChange={e => setFormData({ ...formData, category: e.target.value as Category })}
            >
              {Object.values(Category).map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="md:col-span-2 bg-[#1a1625] text-white py-10 rounded-[3.5rem] font-black text-3xl hover:bg-[#b497ff] transition-all shadow-2xl active:scale-[0.98]">
            Commit to Hearth records
          </button>
        </form>
      )}

      <div className="glass-premium rounded-[5.5rem] border-none overflow-hidden shadow-[0_40px_100px_-40px_rgba(26,22,37,0.1)]">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#1a1625]/5">
                <th className="px-16 py-12 text-[11px] font-black text-[#1a1625] uppercase tracking-[0.7em]">Narrative</th>
                <th className="px-16 py-12 text-[11px] font-black text-[#1a1625] uppercase tracking-[0.7em]">Sphere</th>
                <th className="px-16 py-12 text-[11px] font-black text-[#1a1625] uppercase tracking-[0.7em]">Cycle</th>
                <th className="px-16 py-12 text-[11px] font-black text-[#1a1625] uppercase tracking-[0.7em] text-right">Value</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100/50">
              {transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((t, i) => (
                <tr key={t.id} className="hover:bg-white/60 transition-colors group stagger-item" style={{ animationDelay: `${i * 0.05}s` }}>
                  <td className="px-16 py-12">
                    <span className="font-black text-[#1a1625] text-3xl block leading-none mb-3 group-hover:text-[#b497ff] transition-colors">{t.description}</span>
                    <div className="flex items-center gap-3">
                       <img src={`https://i.pravatar.cc/150?u=${t.userName}`} className="w-5 h-5 rounded-full border border-white" alt="" />
                       <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em]">Authored By {t.userName}</span>
                    </div>
                  </td>
                  <td className="px-16 py-12">
                    <span className="px-10 py-4 bg-white/80 text-[#1a1625] text-[10px] font-black uppercase tracking-widest rounded-full border border-gray-100 shadow-sm group-hover:bg-[#b497ff] group-hover:text-white transition-all">
                      {t.category}
                    </span>
                  </td>
                  <td className="px-16 py-12">
                    <span className="text-gray-300 font-bold text-2xl tracking-tighter">{new Date(t.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span>
                  </td>
                  <td className="px-16 py-12 text-right">
                    <span className="font-black text-5xl text-[#1a1625] tracking-tighter">₹{t.amount.toLocaleString('en-IN')}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Expenses;
