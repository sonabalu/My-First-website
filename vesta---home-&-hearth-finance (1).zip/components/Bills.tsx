
import React, { useState, useMemo } from 'react';
import { Bill, Category } from '../types';

interface BillsProps {
  bills: Bill[];
  onToggle: (id: string) => void;
  // Fix: Exclude familyId from the onAdd parameter since it's handled by the parent
  onAdd: (b: Omit<Bill, 'id' | 'familyId'>) => void;
}

const Bills: React.FC<BillsProps> = ({ bills, onToggle, onAdd }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    dueDate: new Date().toISOString().split('T')[0],
    category: Category.UTILITIES
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Fix: Successfully call onAdd with form fields, matching the updated prop type
    onAdd({
      title: formData.title,
      amount: parseFloat(formData.amount),
      dueDate: formData.dueDate,
      category: formData.category,
      isPaid: false
    });
    setFormData({ title: '', amount: '', dueDate: new Date().toISOString().split('T')[0], category: Category.UTILITIES });
    setIsAdding(false);
  };

  const pending = bills.filter(b => !b.isPaid);
  const paid = bills.filter(b => b.isPaid);

  const totalSpentOnBills = useMemo(() => paid.reduce((acc, b) => acc + b.amount, 0), [paid]);
  const totalPendingOnBills = useMemo(() => pending.reduce((acc, b) => acc + b.amount, 0), [pending]);

  return (
    <div className="space-y-24 animate-bloom">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-12">
        <div>
          <h2 className="text-8xl serif font-bold text-[#1a1625] tracking-tighter title-shimmer">Obligations</h2>
          <p className="text-gray-400 font-medium mt-6 text-2xl leading-relaxed max-w-lg">Guardians of the hearth's foundation. Track and settle with grace.</p>
        </div>
        <div className="flex items-center gap-6">
           <div className="glass-premium px-10 py-6 rounded-[2.5rem] border-emerald-100/50 bg-emerald-50/20">
              <p className="text-[10px] font-black uppercase tracking-[0.5em] text-gray-400 mb-2">Money Settled</p>
              <p className="text-3xl font-black text-emerald-500 tracking-tight">₹{totalSpentOnBills.toLocaleString()}</p>
           </div>
           <button 
            onClick={() => setIsAdding(!isAdding)}
            className="bg-[#1a1625] text-white px-14 py-7 rounded-[2.5rem] font-black text-xs uppercase tracking-[0.5em] hover:scale-105 active:scale-95 transition-all shadow-2xl hover:shadow-[#1a1625]/20"
          >
            {isAdding ? 'Close Ledger' : '+ Record Due'}
          </button>
        </div>
      </header>

      {isAdding && (
        <form onSubmit={handleSubmit} className="glass-premium p-20 rounded-[5rem] grid grid-cols-1 md:grid-cols-2 gap-12 animate-bloom relative overflow-hidden border-2 border-white">
          <div className="absolute -top-24 -right-24 w-80 h-80 bg-purple-100/30 blur-[120px] pointer-events-none"></div>
          <div className="md:col-span-2">
            <label className="block text-[11px] font-black text-[#1a1625] uppercase tracking-[0.6em] mb-6">Identity of Obligation</label>
            <input required type="text" placeholder="e.g. Hearth Internet Infrastructure" className="w-full bg-white/50 border-none rounded-[2.5rem] px-12 py-8 outline-none focus:ring-8 focus:ring-purple-50 font-bold text-3xl shadow-inner transition-all" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} />
          </div>
          <div>
            <label className="block text-[11px] font-black text-[#1a1625] uppercase tracking-[0.6em] mb-6">Required Flow (₹)</label>
            <input required type="number" placeholder="0.00" className="w-full bg-white/50 border-none rounded-[2.5rem] px-12 py-8 outline-none focus:ring-8 focus:ring-purple-50 font-black text-4xl shadow-inner transition-all" value={formData.amount} onChange={e => setFormData({ ...formData, amount: e.target.value })} />
          </div>
          <div>
            <label className="block text-[11px] font-black text-[#1a1625] uppercase tracking-[0.6em] mb-6">Maturity Cycle</label>
            <input required type="date" className="w-full bg-white/50 border-none rounded-[2.5rem] px-12 py-8 outline-none focus:ring-8 focus:ring-purple-50 font-bold text-2xl shadow-inner appearance-none transition-all" value={formData.dueDate} onChange={e => setFormData({ ...formData, dueDate: e.target.value })} />
          </div>
          <button type="submit" className="md:col-span-2 bg-[#1a1625] text-white py-10 rounded-[3.5rem] font-black text-3xl shadow-2xl hover:scale-[1.02] active:scale-95 transition-all">Commit to Ledger</button>
        </form>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
        {/* Pending Section */}
        <div className="space-y-10">
           <div className="flex justify-between items-center border-b border-gray-100 pb-8 px-6">
              <h3 className="text-3xl font-bold text-[#1a1625] serif flex items-center gap-6">
                <span className="w-4 h-4 rounded-full bg-orange-400 animate-pulse shadow-[0_0_15px_rgba(251,146,60,0.5)]"></span>
                Awaiting Action
              </h3>
              <p className="text-[11px] font-black text-orange-400 uppercase tracking-[0.3em]">₹{totalPendingOnBills.toLocaleString()} Total</p>
           </div>
           <div className="space-y-6">
             {pending.map((bill, i) => (
               <div 
                 key={bill.id} 
                 className="glass-premium p-10 rounded-[4rem] flex items-center justify-between group stagger-item border-none"
                 style={{ animationDelay: `${i * 0.1}s` }}
               >
                  <div className="flex items-center gap-8">
                     <div className="w-20 h-20 bg-[#1a1625] text-white rounded-[2.5rem] flex items-center justify-center font-black text-3xl group-hover:rotate-[10deg] transition-transform duration-500">₹</div>
                     <div>
                        <h4 className="font-black text-[#1a1625] text-2xl tracking-tight group-hover:text-[#b497ff] transition-colors mb-2">{bill.title}</h4>
                        <p className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-400">Due {new Date(bill.dueDate).toLocaleDateString('en-IN', {day: 'numeric', month: 'long'})}</p>
                     </div>
                  </div>
                  <div className="text-right">
                     <p className="text-4xl font-black text-[#1a1625] tracking-tighter mb-4">₹{bill.amount.toLocaleString()}</p>
                     <button 
                        onClick={() => onToggle(bill.id)} 
                        className="text-[10px] font-black uppercase tracking-[0.5em] bg-[#1a1625] text-white px-10 py-4 rounded-full hover:bg-emerald-500 transition-all shadow-xl hover:shadow-emerald-500/20 active:scale-90"
                      >
                        Settle
                      </button>
                  </div>
               </div>
             ))}
             {pending.length === 0 && (
               <div className="text-center py-24 bg-emerald-50/20 rounded-[5rem] border-2 border-dashed border-emerald-100/50">
                 <p className="text-emerald-400 font-bold italic text-xl">Sanctuary harmony maintained. All dues settled.</p>
               </div>
             )}
           </div>
        </div>

        {/* Settled Section */}
        <div className="space-y-10 opacity-60 hover:opacity-100 transition-opacity duration-700">
           <div className="flex justify-between items-center border-b border-gray-100 pb-8 px-6">
              <h3 className="text-3xl font-bold text-gray-400 serif flex items-center gap-6">
                <span className="w-4 h-4 rounded-full bg-emerald-400 shadow-[0_0_15px_rgba(52,211,153,0.3)]"></span>
                History of Settlement
              </h3>
              <p className="text-[11px] font-black text-emerald-400 uppercase tracking-[0.3em]">₹{totalSpentOnBills.toLocaleString()} Total</p>
           </div>
           <div className="space-y-6">
             {paid.map((bill, i) => (
               <div 
                 key={bill.id} 
                 className="bg-white/40 backdrop-blur-sm p-10 rounded-[4rem] border border-gray-100 flex items-center justify-between grayscale-[0.8] hover:grayscale-0 transition-all stagger-item"
                 style={{ animationDelay: `${i * 0.05}s` }}
               >
                  <div className="flex items-center gap-8">
                     <div className="w-20 h-20 bg-emerald-50 text-emerald-400 rounded-[2.5rem] flex items-center justify-center">
                        <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
                     </div>
                     <div>
                        <h4 className="font-bold text-gray-400 line-through text-2xl mb-1">{bill.title}</h4>
                        <div className="flex items-center gap-2">
                           <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                           <p className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.4em]">Settled Ledger</p>
                        </div>
                     </div>
                  </div>
                  <p className="text-3xl font-black text-gray-400 tracking-tighter">₹{bill.amount.toLocaleString()}</p>
               </div>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default Bills;
