
import React from 'react';
import { User } from '../types';

interface IdentityProps {
  user: User;
  onLogout: () => void;
}

const Identity: React.FC<IdentityProps> = ({ user, onLogout }) => {
  return (
    <div className="space-y-16 animate-bloom">
      <header>
        <h2 className="text-8xl serif font-bold text-[#1a1625] tracking-tighter title-shimmer">Identity</h2>
        <p className="text-gray-400 font-medium mt-6 text-2xl">Manage your presence within the hearth.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 glass-premium p-16 rounded-[5rem] flex flex-col items-center md:items-start md:flex-row gap-12 border-none">
          <div className="relative group">
            <img src={user.avatar} className="w-48 h-48 rounded-[4rem] object-cover shadow-2xl transition-transform group-hover:scale-105" alt="" />
            <div className="absolute -bottom-4 -right-4 bg-emerald-400 text-white p-4 rounded-full shadow-2xl animate-pulse">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4" />
               </svg>
            </div>
          </div>
          <div className="space-y-6 text-center md:text-left">
            <div>
              <h3 className="text-5xl font-black text-[#1a1625] tracking-tight">{user.name}</h3>
              <p className="text-[11px] font-black uppercase tracking-[0.5em] text-[#b497ff] mt-2">{user.role}</p>
            </div>
            <div className="space-y-2">
              <p className="text-gray-400 font-bold text-lg">{user.email}</p>
              <p className="text-gray-300 text-sm">Hearth ID: <span className="font-mono">{user.id}</span></p>
            </div>
            <div className="pt-6">
               <button className="bg-[#1a1625]/5 text-[#1a1625] px-8 py-4 rounded-[1.5rem] font-black text-xs uppercase tracking-widest hover:bg-[#1a1625] hover:text-white transition-all">Edit Scroll</button>
            </div>
          </div>
        </div>

        <div className="space-y-8">
           <div className="glass-premium p-10 rounded-[4rem] border-none">
              <h4 className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-6">Security Vault</h4>
              <button className="w-full text-left p-6 bg-white/60 rounded-[2rem] hover:bg-white transition-all flex items-center justify-between group">
                <span className="font-bold text-[#1a1625]">Change Vault Sequence</span>
                <svg className="w-5 h-5 text-gray-300 group-hover:text-[#1a1625] transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 5l7 7-7 7" /></svg>
              </button>
           </div>

           <div className="glass-premium p-10 rounded-[4rem] border-none">
              <h4 className="text-[11px] font-black text-rose-400 uppercase tracking-widest mb-6">Depart</h4>
              <button 
                onClick={onLogout}
                className="w-full py-7 bg-rose-50 text-rose-500 rounded-[2.5rem] font-black text-xs uppercase tracking-[0.4em] hover:bg-rose-500 hover:text-white transition-all shadow-xl hover:shadow-rose-500/20 active:scale-95"
              >
                Extinguish Session
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Identity;
