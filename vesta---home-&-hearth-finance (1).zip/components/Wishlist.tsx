
import React, { useState } from 'react';
import { WishlistItem, Category } from '../types';

interface WishlistProps {
  items: WishlistItem[];
  // Fix: Exclude internal fields (id, votes, familyId) from onAdd parameter
  onAdd: (item: Omit<WishlistItem, 'id' | 'votes' | 'familyId'>) => void;
  onVote: (id: string) => void;
}

const Wishlist: React.FC<WishlistProps> = ({ items, onAdd, onVote }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    price: '',
    category: Category.OTHER,
    imageUrl: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Fix: Successfully call onAdd with the fields collected in the form, now matching the updated prop type
    onAdd({
      title: formData.title,
      price: parseFloat(formData.price),
      suggestedBy: 'Arjun',
      category: formData.category,
      imageUrl: formData.imageUrl || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=400'
    });
    setFormData({ title: '', price: '', category: Category.OTHER, imageUrl: '' });
    setIsAdding(false);
  };

  return (
    <div className="space-y-16 animate-bloom">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
        <div>
          <h2 className="text-7xl serif font-bold text-[#1e1b29] title-shimmer">Hearth Desires</h2>
          <p className="text-gray-400 font-medium mt-4 text-xl">Future logs we dream of collectively.</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="btn-midnight px-12 py-6 rounded-[2.5rem] font-black text-xs uppercase tracking-[0.4em]"
        >
          {isAdding ? 'Archive' : '+ Suggest Desire'}
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSubmit} className="glass-premium p-16 rounded-[4rem] grid grid-cols-1 md:grid-cols-2 gap-12 animate-bloom">
          <div className="md:col-span-2">
            <label className="block text-[11px] font-black text-gray-400 uppercase tracking-widest mb-4">The Shared Vision</label>
            <input required type="text" placeholder="e.g. Handmade Oak Dining Table" className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-7 outline-none focus:ring-4 focus:ring-purple-100 font-bold text-2xl shadow-inner" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} />
          </div>
          <div>
            <label className="block text-[11px] font-black text-gray-400 uppercase tracking-widest mb-4">Estimated Offering (₹)</label>
            <input required type="number" placeholder="0.00" className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-7 outline-none focus:ring-4 focus:ring-purple-100 font-bold text-2xl shadow-inner" value={formData.price} onChange={e => setFormData({ ...formData, price: e.target.value })} />
          </div>
          <div>
            <label className="block text-[11px] font-black text-gray-400 uppercase tracking-widest mb-4">Vibe Sphere</label>
            <select className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-7 outline-none focus:ring-4 focus:ring-purple-100 font-bold text-2xl appearance-none shadow-inner" value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value as Category })}>
              {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <button type="submit" className="md:col-span-2 btn-midnight py-8 rounded-[3rem] font-black text-2xl shadow-2xl">Cast Suggestion</button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
        {items.sort((a, b) => b.votes - a.votes).map(item => (
          <div key={item.id} className="glass-premium rounded-[4rem] overflow-hidden group soft-hover border-none">
            <div className="h-72 relative overflow-hidden">
              <img src={item.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[4000ms] grayscale-[0.3] group-hover:grayscale-0" alt={item.title} />
              <div className="absolute top-6 right-6 bg-white/95 backdrop-blur px-6 py-3 rounded-full shadow-2xl">
                 <p className="text-xs font-black text-[#1e1b29]">₹{item.price.toLocaleString('en-IN')}</p>
              </div>
            </div>
            <div className="p-10 space-y-8">
              <h3 className="text-4xl font-black serif text-[#1e1b29] tracking-tight leading-none">{item.title}</h3>
              <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                 <p className="text-[10px] font-black uppercase tracking-widest text-gray-300">Origin: {item.suggestedBy}</p>
                 <button 
                  onClick={() => onVote(item.id)}
                  className="flex items-center gap-3 bg-[#1e1b29] text-white px-6 py-4 rounded-full transition-all active:scale-90 shadow-xl group/btn"
                 >
                   <span className="text-lg transition-transform group-hover/btn:scale-125">💜</span>
                   <span className="font-black text-sm">{item.votes}</span>
                 </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Wishlist;
