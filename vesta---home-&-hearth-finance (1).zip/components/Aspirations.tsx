
import React, { useState } from 'react';
import { SavingsGoal, WishlistItem, Category } from '../types';

interface AspirationsProps {
  visions: SavingsGoal[];
  desires: WishlistItem[];
  onAddVision: (v: Omit<SavingsGoal, 'id' | 'familyId'>) => void;
  onUpdateVision: (id: string, amount: number) => void;
  onAddDesire: (d: Omit<WishlistItem, 'id' | 'votes' | 'familyId'>) => void;
  onVoteDesire: (id: string) => void;
}

const CATEGORY_IMAGES: Record<string, string> = {
  vacation: 'https://images.unsplash.com/photo-1506484334402-40ff22e05a6d?auto=format&fit=crop&q=80&w=800',
  emergency: 'https://images.unsplash.com/photo-1542810634-71277d95dcbb?auto=format&fit=crop&q=80&w=800',
  'large-purchase': 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=800',
  other: 'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&q=80&w=800'
};

const Aspirations: React.FC<AspirationsProps> = ({ visions, desires, onAddVision, onUpdateVision, onAddDesire, onVoteDesire }) => {
  const [activeSubTab, setActiveSubTab] = useState<'visions' | 'desires'>('visions');
  const [showAdd, setShowAdd] = useState(false);
  const [contAmount, setContAmount] = useState('');
  const [activeGoalId, setActiveGoalId] = useState<string | null>(null);

  const [visionForm, setVisionForm] = useState({ name: '', target: '', cat: 'vacation' as any });
  const [desireForm, setDesireForm] = useState({ title: '', price: '', cat: Category.OTHER, img: '' });

  const handleVisionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddVision({ name: visionForm.name, targetAmount: parseFloat(visionForm.target), currentAmount: 0, category: visionForm.cat });
    setVisionForm({ name: '', target: '', cat: 'vacation' });
    setShowAdd(false);
  };

  const handleDesireSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddDesire({ title: desireForm.title, price: parseFloat(desireForm.price), category: desireForm.cat, suggestedBy: 'Me', imageUrl: desireForm.img });
    setDesireForm({ title: '', price: '', cat: Category.OTHER, img: '' });
    setShowAdd(false);
  };

  return (
    <div className="space-y-16 animate-bloom">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
        <div>
          <h2 className="text-8xl serif font-bold text-[#1a1625] tracking-tighter title-shimmer">Aspirations</h2>
          <p className="text-gray-400 font-medium mt-6 text-2xl">Visions of long-term prosperity and desires of immediate joy.</p>
        </div>
        <button 
          onClick={() => setShowAdd(!showAdd)}
          className="bg-[#1a1625] text-white px-14 py-7 rounded-[2.5rem] font-black text-xs uppercase tracking-[0.5em] hover:scale-105 active:scale-95 transition-all shadow-2xl"
        >
          {showAdd ? 'Close' : `+ New ${activeSubTab === 'visions' ? 'Vision' : 'Desire'}`}
        </button>
      </div>

      <div className="flex gap-4 p-2 bg-[#1a1625]/5 rounded-[3rem] w-fit">
        <button onClick={() => setActiveSubTab('visions')} className={`px-12 py-5 rounded-[2.5rem] font-black text-xs uppercase tracking-widest transition-all ${activeSubTab === 'visions' ? 'bg-[#1a1625] text-white shadow-xl' : 'text-gray-400'}`}>Visions</button>
        <button onClick={() => setActiveSubTab('desires')} className={`px-12 py-5 rounded-[2.5rem] font-black text-xs uppercase tracking-widest transition-all ${activeSubTab === 'desires' ? 'bg-[#1a1625] text-white shadow-xl' : 'text-gray-400'}`}>Desires</button>
      </div>

      {showAdd && (
        activeSubTab === 'visions' ? (
          <form onSubmit={handleVisionSubmit} className="glass-premium p-16 rounded-[4rem] grid grid-cols-1 md:grid-cols-2 gap-10 animate-bloom">
             <div className="md:col-span-2">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Vision Name</label>
                <input required type="text" className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-6 outline-none font-bold text-2xl" value={visionForm.name} onChange={e => setVisionForm({...visionForm, name: e.target.value})} />
             </div>
             <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Target Amount (₹)</label>
                <input required type="number" className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-6 outline-none font-bold text-2xl" value={visionForm.target} onChange={e => setVisionForm({...visionForm, target: e.target.value})} />
             </div>
             <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Category</label>
                <select className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-6 outline-none font-bold text-2xl appearance-none" value={visionForm.cat} onChange={e => setVisionForm({...visionForm, cat: e.target.value as any})}>
                   <option value="vacation">Vacation</option>
                   <option value="emergency">Emergency</option>
                   <option value="large-purchase">Large Purchase</option>
                </select>
             </div>
             <button type="submit" className="md:col-span-2 bg-[#1a1625] text-white py-8 rounded-[3rem] font-black text-2xl">Confirm Vision</button>
          </form>
        ) : (
          <form onSubmit={handleDesireSubmit} className="glass-premium p-16 rounded-[4rem] grid grid-cols-1 md:grid-cols-2 gap-10 animate-bloom">
             <div className="md:col-span-2">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Desire Item</label>
                <input required type="text" className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-6 outline-none font-bold text-2xl" value={desireForm.title} onChange={e => setDesireForm({...desireForm, title: e.target.value})} />
             </div>
             <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Est. Cost (₹)</label>
                <input required type="number" className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-6 outline-none font-bold text-2xl" value={desireForm.price} onChange={e => setDesireForm({...desireForm, price: e.target.value})} />
             </div>
             <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Sphere</label>
                <select className="w-full bg-white/60 border-none rounded-[2rem] px-10 py-6 outline-none font-bold text-2xl appearance-none" value={desireForm.cat} onChange={e => setDesireForm({...desireForm, cat: e.target.value as any})}>
                   {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                </select>
             </div>
             <button type="submit" className="md:col-span-2 bg-[#1a1625] text-white py-8 rounded-[3rem] font-black text-2xl">Cast Desire</button>
          </form>
        )
      )}

      {activeSubTab === 'visions' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {visions.map(v => {
            const progress = (v.currentAmount / v.targetAmount) * 100;
            return (
              <div key={v.id} className="glass-premium p-10 rounded-[4rem] group border-none shadow-sm hover:shadow-xl transition-all">
                <div className="h-64 rounded-[3rem] overflow-hidden mb-8 relative">
                   <img src={CATEGORY_IMAGES[v.category] || CATEGORY_IMAGES.other} className="w-full h-full object-cover transition-transform group-hover:scale-110" alt="" />
                   <div className="absolute inset-0 bg-gradient-to-t from-[#1a1625] to-transparent opacity-60"></div>
                   <div className="absolute bottom-8 left-8">
                      <h3 className="text-4xl font-bold serif text-white">{v.name}</h3>
                      <p className="text-[10px] font-black text-white/70 uppercase tracking-widest">{v.category}</p>
                   </div>
                </div>
                <div className="space-y-6">
                   <div className="flex justify-between items-end">
                      <p className="text-5xl font-black text-[#1a1625] tracking-tighter">₹{v.currentAmount.toLocaleString()}</p>
                      <p className="text-xl font-bold text-gray-300 tracking-tighter">Target: ₹{v.targetAmount.toLocaleString()}</p>
                   </div>
                   <div className="h-4 bg-[#1a1625]/5 rounded-full overflow-hidden p-1">
                      <div className="h-full bg-gradient-to-r from-[#b497ff] to-[#ff8e7a] rounded-full transition-all duration-1000" style={{ width: `${progress}%` }}></div>
                   </div>
                   <div className="pt-4 flex gap-4">
                      <input 
                        type="number" 
                        placeholder="Log contrib..." 
                        className="flex-1 bg-white border-none rounded-[1.5rem] px-6 py-4 text-sm font-bold shadow-inner"
                        value={activeGoalId === v.id ? contAmount : ''}
                        onChange={e => { setContAmount(e.target.value); setActiveGoalId(v.id); }}
                      />
                      <button 
                        onClick={() => { if(activeGoalId === v.id) onUpdateVision(v.id, parseFloat(contAmount)); setContAmount(''); setActiveGoalId(null); }}
                        className="bg-[#1a1625] text-white px-8 py-4 rounded-2xl font-black text-xs hover:bg-[#b497ff] transition-all"
                      >
                        Add
                      </button>
                   </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {desires.map(item => (
            <div key={item.id} className="glass-premium rounded-[4rem] overflow-hidden group border-none">
              <div className="h-72 relative overflow-hidden">
                <img src={item.imageUrl || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=400'} className="w-full h-full object-cover group-hover:scale-110 transition-transform" alt="" />
                <div className="absolute top-6 right-6 bg-white/95 px-6 py-3 rounded-full shadow-xl">
                   <p className="text-xs font-black text-[#1a1625]">₹{item.price.toLocaleString()}</p>
                </div>
              </div>
              <div className="p-10 space-y-8">
                <h3 className="text-4xl font-black serif text-[#1a1625] tracking-tight leading-none">{item.title}</h3>
                <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                   <p className="text-[10px] font-black uppercase tracking-widest text-gray-300">By {item.suggestedBy}</p>
                   <button onClick={() => onVoteDesire(item.id)} className="flex items-center gap-3 bg-[#1a1625] text-white px-6 py-4 rounded-full shadow-xl active:scale-90 transition-all">
                     <span className="text-lg">💜</span>
                     <span className="font-black text-sm">{item.votes}</span>
                   </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Aspirations;
